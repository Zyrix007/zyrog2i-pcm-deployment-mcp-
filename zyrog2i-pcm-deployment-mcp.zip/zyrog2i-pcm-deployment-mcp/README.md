# ZyroG2i Persistent Context Manager (PCM) & Task Maxer — Deployment MCP Server (MVP v2)

Specification ID: `ZyroG2i_PCM_Deployment_MCP_MVP_v2`

A local Model Context Protocol (MCP) server implementing the deployment-time **Persistent Context Manager (PCM)** and **Task Maxer** state protocol for the ZyroG2i / Xlyo runtime stack (`Zyro` internal coordinator, `Zyru` specification/communication interface, `Zyrix` product identity).

## Architecture Overview

```
+-------------------------------------------------------------------+
|                   MCP-Compatible Local Host                       |
|        (Spawns process, communicates over stdio JSON-RPC 2.0)     |
+---------------------------------+---------------------------------+
                                  |
                     stdin / stdout (Protocol-Only)
                     stderr (Structured JSON Diagnostics)
                                  |
                                  v
+-------------------------------------------------------------------+
|               MCP Transport & Tool Layer (src/mcp/)               |
|  - server.ts: MCP Server lifecycle & stdio transport binding      |
|  - tools.ts:  31 narrow, explicitly typed read/write MCP tools    |
+---------------------------------+---------------------------------+
                                  |
                                  v
+-------------------------------------------------------------------+
|          Domain & Service Layer (src/domain/, src/services/)      |
|  - Server-bound namespace authority (rejects spoofing)            |
|  - Optimistic concurrency (expected_version -> VERSION_CONFLICT)  |
|  - Task Maxer state machine & completion criteria validation      |
|  - Secret rejection, artifact root path/symlink confinement       |
|  - Bounded worker context bundle assembly                         |
+---------------------------------+---------------------------------+
                                  |
                                  v
+-------------------------------------------------------------------+
|             Storage Layer (src/storage/, native/)                 |
|  - native/sqlite_napi.c -> build/sqlite_napi.node (libsqlite3)    |
|  - Parameterized prepared statements, PRAGMA foreign_keys = ON    |
|  - Atomic transaction wrapper (Entity Mutation + Receipt + Idem)  |
|  - SQLite Online Backup API (sqlite3_backup_init) for exports     |
+-------------------------------------------------------------------+
```

### Separation of Responsibilities
- **PCM** owns durable operational state, versioned records, optimistic concurrency, and immutable audit receipts. It never invents facts, probabilities, suitability scores, or verification outcomes.
- **Task Maxer** is the task-oriented current-state board built on PCM (`tasks`), keeping confirmed specifications distinct from assumptions, enforcing status transition rules, preventing premature completion when mandatory acceptance criteria or verification are unmet, and preventing silent removal of unresolved blockers, open questions, or dependencies.
- **Decision Layer (e.g., Laya)** supplies structured choices, option probabilities, suitability scores, and evidence references via `pcm_decision_append` and `pcm_runtime_route_append`; PCM validates and records them without acting as decision maker or ground-truth verifier.
- **Capability Observations** (`pcm_capability_observation_record` / `pcm_capability_observation_get`) store externally supplied static capabilities, measured performance, and last-known availability with explicit freshness/staleness labels (`fresh`, `stale`, `expired`). PCM never probes or schedules hardware.

## Environment Variables & Configuration

Configure the server using environment variables (see `.env.example`):

| Variable | Default | Description |
| :--- | :--- | :--- |
| `PCM_DATA_DIR` | `~/.local/share/zyrog2i-pcm` | Per-user application data directory containing `pcm.sqlite`. |
| `PCM_NAMESPACE` | `default` | Server-enforced namespace authority (`[a-zA-Z0-9._-]{1,64}`). Caller-supplied namespaces are rejected with `NAMESPACE_MISMATCH`. |
| `PCM_ARTIFACT_ROOT` | `$PCM_DATA_DIR/artifacts` | Controlled root directory for local artifact references. Path traversal (`..`), absolute paths, `file://` URIs, and symlink escapes outside this directory are rejected with `PATH_NOT_ALLOWED`. |
| `PCM_EXPORT_DIR` | `$PCM_DATA_DIR/exports` | Controlled output directory for consistent JSON snapshots. |
| `PCM_LOG_LEVEL` | `info` | Diagnostic stderr logging level (`debug`, `info`, `warn`, `error`, `silent`). `stdout` is strictly reserved for MCP JSON-RPC protocol frames. |

## Setup, Build, and Run Instructions

### Prerequisites
- Node.js `>= 18.0.0` (verified on Node.js `v18.20.4`)
- `gcc` + Node N-API headers (`/usr/include/node/node_api.h`) + `libsqlite3.so.0` (SQLite `3.40.1`)

### Build & Typecheck
```bash
npm run build
npm run typecheck
```
- `npm run build` compiles the in-process N-API SQLite3 binding (`native/sqlite_napi.c` -> `build/sqlite_napi.node`), verifies the `@modelcontextprotocol/sdk` runtime module, and transpiles TypeScript (`src/**/*.ts` -> `dist/**/*.js`).
- `npm run typecheck` parses all TypeScript source and test files (`src/` and `tests/`), validates relative module resolution, and verifies clean TypeScript compilation.

### Run the MCP Server (stdio)
```bash
PCM_DATA_DIR=/var/tmp/pcm-data \
PCM_NAMESPACE=default \
PCM_ARTIFACT_ROOT=/var/tmp/pcm-data/artifacts \
PCM_EXPORT_DIR=/var/tmp/pcm-data/exports \
PCM_LOG_LEVEL=info \
npm start
```

### Run Automated Tests
```bash
npm test
# Or run individual suites:
npm run test:unit
npm run test:integration
npm run test:security
```

## Storage, Migrations, and Consistent Backup

1. **Durable SQLite Persistence**: Database connections open `pcm.sqlite` in `WAL` mode with `PRAGMA foreign_keys = ON;` verified at startup. Passing `:memory:` is explicitly rejected with `STORAGE_UNAVAILABLE`.
2. **Transactional Schema Migrations**: On startup, `SqliteDatabase.runMigrations()` applies unapplied migrations from `src/storage/migrations/index.ts` inside an `IMMEDIATE` transaction and records SHA-256 checksums in `schema_migrations`.
3. **Consistent Snapshot Export (`pcm_snapshot_export`)**:
   - Uses SQLite's C Online Backup API (`sqlite3_backup_init`, `sqlite3_backup_step(-1)`, `sqlite3_backup_finish`) to capture a point-in-time consistent database snapshot before reading namespace-scoped records.
   - Exports only records matching the server's configured `PCM_NAMESPACE`.
   - Applies recursive secret redaction, computes a SHA-256 data checksum, embeds a schema/version manifest, and atomically writes a generated safe filename (`pcm-snapshot-<namespace>-<label>-<timestamp>-<id>.json`) inside `PCM_EXPORT_DIR`. Never uploads data externally.

## MCP Host Configuration & Gemini Compatibility Caveat

### Connecting from a Local Stdio MCP Host (e.g., Claude Desktop, Cursor, MCP Inspector)
Add the following entry to your host's MCP server configuration:
```json
{
  "mcpServers": {
    "zyrog2i-pcm": {
      "command": "node",
      "args": ["/absolute/path/to/dist/index.js"],
      "env": {
        "PCM_DATA_DIR": "/var/tmp/pcm-data",
        "PCM_NAMESPACE": "default",
        "PCM_ARTIFACT_ROOT": "/var/tmp/pcm-data/artifacts",
        "PCM_EXPORT_DIR": "/var/tmp/pcm-data/exports",
        "PCM_LOG_LEVEL": "info"
      }
    }
  }
}
```

### Gemini Apps Compatibility Caveat
- A local `stdio` MCP server runs as a child process on your local machine and is **not automatically connectable from web-hosted Gemini Apps**.
- To use this server directly, your MCP host must support spawning local `stdio` MCP servers.
- Integrating with Gemini custom apps or cloud-hosted extensions requires an আলাদা (separate) reachable HTTPS/SSE/Streamable-HTTP MCP endpoint and appropriate account/region eligibility. Per the v1 specification, this project does **not** open network ports or deploy a public endpoint; domain and storage layers (`src/services/pcm-service.ts`, `src/storage/`) are kept strictly transport-independent so an HTTP/SSE adapter can be added in a future release.

## Registered Narrow MCP Tools (31 Tools)

| Category | Read Tools | Write Tools |
| :--- | :--- | :--- |
| **Health & Context** | `pcm_health`, `pcm_context_bundle_get` | — |
| **Profile** | `pcm_profile_get` | `pcm_profile_update` |
| **Memory** | `pcm_memory_search` | `pcm_memory_create`, `pcm_memory_update`, `pcm_memory_archive`, `pcm_memory_forget` |
| **Project** | `pcm_project_get`, `pcm_project_list` | `pcm_project_create`, `pcm_project_update` |
| **Task Maxer** | `pcm_task_get`, `pcm_task_list` | `pcm_task_create`, `pcm_task_update` |
| **Decisions** | `pcm_decision_list` | `pcm_decision_append` |
| **Artifacts** | `pcm_artifact_list` | `pcm_artifact_register` |
| **Receipts** | `pcm_receipt_search` | `pcm_receipt_append` |
| **Runtime Routes** | `pcm_runtime_route_list` | `pcm_runtime_route_append` |
| **Capabilities** | `pcm_capability_observation_get` | `pcm_capability_observation_record` |
| **Knowledge Nav** | `pcm_knowledge_navigation_get` | `pcm_knowledge_navigation_update`, `pcm_knowledge_navigation_get_update` |
| **Backup/Export** | — | `pcm_snapshot_export` |
