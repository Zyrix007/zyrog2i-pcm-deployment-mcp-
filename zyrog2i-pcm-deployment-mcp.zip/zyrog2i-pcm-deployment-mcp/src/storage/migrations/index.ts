import * as crypto from 'crypto';

export interface MigrationDefinition {
  version: number;
  name: string;
  sql: string;
}

export const MIGRATIONS: MigrationDefinition[] = [
  {
    version: 1,
    name: '001_initial_pcm_schema',
    sql: `
      -- 1. User Profiles (1 per namespace)
      CREATE TABLE IF NOT EXISTS profiles (
        id TEXT PRIMARY KEY,
        namespace_id TEXT NOT NULL UNIQUE,
        clarification_strictness TEXT NOT NULL,
        risk_tolerance TEXT NOT NULL,
        tone TEXT NOT NULL,
        verbosity TEXT NOT NULL,
        expertise_mode TEXT NOT NULL,
        assumption_handling TEXT NOT NULL,
        verification_effort TEXT NOT NULL,
        autonomy TEXT NOT NULL,
        version INTEGER NOT NULL DEFAULT 1 CHECK (version >= 1),
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_profiles_namespace ON profiles(namespace_id);

      -- 2. Projects
      CREATE TABLE IF NOT EXISTS projects (
        id TEXT PRIMARY KEY,
        namespace_id TEXT NOT NULL,
        name TEXT NOT NULL,
        description TEXT,
        objectives_json TEXT NOT NULL DEFAULT '[]',
        constraints_json TEXT NOT NULL DEFAULT '[]',
        status TEXT NOT NULL CHECK (status IN ('active', 'paused', 'completed', 'archived')),
        version INTEGER NOT NULL DEFAULT 1 CHECK (version >= 1),
        provenance_json TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        UNIQUE (id, namespace_id)
      );
      CREATE INDEX IF NOT EXISTS idx_projects_ns_status ON projects(namespace_id, status);
      CREATE INDEX IF NOT EXISTS idx_projects_ns_updated ON projects(namespace_id, updated_at DESC);

      -- 3. Tasks (Task Maxer)
      CREATE TABLE IF NOT EXISTS tasks (
        id TEXT PRIMARY KEY,
        namespace_id TEXT NOT NULL,
        project_id TEXT,
        title TEXT NOT NULL,
        initial_request_summary TEXT,
        confirmed_specification_json TEXT NOT NULL,
        constraints_json TEXT NOT NULL DEFAULT '[]',
        assumptions_json TEXT NOT NULL DEFAULT '[]',
        acceptance_criteria_json TEXT NOT NULL DEFAULT '[]',
        status TEXT NOT NULL CHECK (status IN (
          'draft', 'ready', 'active', 'blocked', 'needs_user',
          'needs_verification', 'completed', 'failed', 'archived'
        )),
        priority TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'critical')),
        current_stage TEXT,
        assignments_json TEXT NOT NULL DEFAULT '[]',
        dependency_refs_json TEXT NOT NULL DEFAULT '[]',
        open_questions_json TEXT NOT NULL DEFAULT '[]',
        blockers_json TEXT NOT NULL DEFAULT '[]',
        verification_status TEXT NOT NULL CHECK (verification_status IN (
          'not_required', 'not_started', 'pending', 'passed', 'failed', 'inconclusive'
        )),
        version INTEGER NOT NULL DEFAULT 1 CHECK (version >= 1),
        provenance_json TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        UNIQUE (id, namespace_id),
        FOREIGN KEY (project_id, namespace_id) REFERENCES projects(id, namespace_id) ON DELETE RESTRICT
      );
      CREATE INDEX IF NOT EXISTS idx_tasks_ns_status ON tasks(namespace_id, status);
      CREATE INDEX IF NOT EXISTS idx_tasks_ns_project ON tasks(namespace_id, project_id);
      CREATE INDEX IF NOT EXISTS idx_tasks_ns_updated ON tasks(namespace_id, updated_at DESC);

      -- 4. Memories
      CREATE TABLE IF NOT EXISTS memories (
        id TEXT PRIMARY KEY,
        namespace_id TEXT NOT NULL,
        content TEXT NOT NULL,
        type TEXT NOT NULL CHECK (type IN (
          'confirmed_fact', 'assumption', 'model_claim', 'preference', 'working_note'
        )),
        scope TEXT NOT NULL CHECK (scope IN ('user', 'project', 'task')),
        project_id TEXT,
        task_id TEXT,
        tags_json TEXT NOT NULL DEFAULT '[]',
        source_type TEXT,
        source_ref TEXT,
        confidence REAL CHECK (confidence IS NULL OR (confidence >= 0.0 AND confidence <= 1.0)),
        privacy_classification TEXT NOT NULL DEFAULT 'internal' CHECK (privacy_classification IN (
          'public', 'internal', 'confidential', 'restricted'
        )),
        expires_at TEXT,
        status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'archived', 'superseded')),
        version INTEGER NOT NULL DEFAULT 1 CHECK (version >= 1),
        provenance_json TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (project_id, namespace_id) REFERENCES projects(id, namespace_id) ON DELETE RESTRICT,
        FOREIGN KEY (task_id, namespace_id) REFERENCES tasks(id, namespace_id) ON DELETE RESTRICT
      );
      CREATE INDEX IF NOT EXISTS idx_memories_ns_status ON memories(namespace_id, status);
      CREATE INDEX IF NOT EXISTS idx_memories_ns_scope ON memories(namespace_id, scope);
      CREATE INDEX IF NOT EXISTS idx_memories_ns_project ON memories(namespace_id, project_id);
      CREATE INDEX IF NOT EXISTS idx_memories_ns_task ON memories(namespace_id, task_id);
      CREATE INDEX IF NOT EXISTS idx_memories_ns_updated ON memories(namespace_id, updated_at DESC);

      -- Memory Search Index (explicit inverted/search index table purged on permanent forget)
      CREATE TABLE IF NOT EXISTS memories_search_index (
        memory_id TEXT PRIMARY KEY,
        namespace_id TEXT NOT NULL,
        searchable_text TEXT NOT NULL,
        tags_text TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (memory_id) REFERENCES memories(id) ON DELETE CASCADE
      );
      CREATE INDEX IF NOT EXISTS idx_memories_search_ns ON memories_search_index(namespace_id);

      -- 5. Structured Decisions
      CREATE TABLE IF NOT EXISTS decisions (
        id TEXT PRIMARY KEY,
        namespace_id TEXT NOT NULL,
        task_id TEXT NOT NULL,
        state_version_observed INTEGER NOT NULL CHECK (state_version_observed >= 1),
        objective TEXT NOT NULL,
        options_json TEXT NOT NULL,
        chosen_option TEXT NOT NULL,
        selection_basis TEXT,
        assessment_confidence REAL CHECK (assessment_confidence IS NULL OR (assessment_confidence >= 0.0 AND assessment_confidence <= 1.0)),
        escalation TEXT,
        evidence_refs_json TEXT NOT NULL DEFAULT '[]',
        provenance_json TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (task_id, namespace_id) REFERENCES tasks(id, namespace_id) ON DELETE RESTRICT
      );
      CREATE INDEX IF NOT EXISTS idx_decisions_ns_task_created ON decisions(namespace_id, task_id, created_at DESC);

      -- 6. Artifacts
      CREATE TABLE IF NOT EXISTS artifacts (
        id TEXT PRIMARY KEY,
        namespace_id TEXT NOT NULL,
        task_id TEXT,
        project_id TEXT,
        name TEXT NOT NULL,
        description TEXT,
        type TEXT NOT NULL,
        relative_path_or_external_reference TEXT NOT NULL,
        mime_type TEXT,
        size_bytes INTEGER CHECK (size_bytes IS NULL OR size_bytes >= 0),
        checksum TEXT,
        provenance_json TEXT,
        verification_status TEXT NOT NULL DEFAULT 'unverified' CHECK (verification_status IN (
          'unverified', 'pending', 'verified', 'failed'
        )),
        created_at TEXT NOT NULL,
        FOREIGN KEY (task_id, namespace_id) REFERENCES tasks(id, namespace_id) ON DELETE RESTRICT,
        FOREIGN KEY (project_id, namespace_id) REFERENCES projects(id, namespace_id) ON DELETE RESTRICT
      );
      CREATE INDEX IF NOT EXISTS idx_artifacts_ns_task ON artifacts(namespace_id, task_id, created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_artifacts_ns_project ON artifacts(namespace_id, project_id, created_at DESC);

      -- 7. Runtime Routes
      CREATE TABLE IF NOT EXISTS runtime_routes (
        id TEXT PRIMARY KEY,
        namespace_id TEXT NOT NULL,
        task_id TEXT NOT NULL,
        route_summary TEXT NOT NULL,
        status TEXT NOT NULL CHECK (status IN (
          'proposed', 'unverified', 'viable', 'partially_viable', 'failed', 'blocked'
        )),
        assessment_confidence REAL CHECK (assessment_confidence IS NULL OR (assessment_confidence >= 0.0 AND assessment_confidence <= 1.0)),
        selection_probability REAL CHECK (selection_probability IS NULL OR (selection_probability >= 0.0 AND selection_probability <= 1.0)),
        suitability_score REAL CHECK (suitability_score IS NULL OR (suitability_score >= 0.0 AND suitability_score <= 1.0)),
        observations_json TEXT NOT NULL DEFAULT '[]',
        evidence_refs_json TEXT NOT NULL DEFAULT '[]',
        next_action TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (task_id, namespace_id) REFERENCES tasks(id, namespace_id) ON DELETE RESTRICT
      );
      CREATE INDEX IF NOT EXISTS idx_routes_ns_task_created ON runtime_routes(namespace_id, task_id, created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_routes_ns_status ON runtime_routes(namespace_id, status);

      -- 8. Operational Receipts
      CREATE TABLE IF NOT EXISTS receipts (
        id TEXT PRIMARY KEY,
        namespace_id TEXT NOT NULL,
        task_id TEXT,
        project_id TEXT,
        correlation_id TEXT,
        idempotency_key TEXT,
        event_type TEXT NOT NULL,
        operation TEXT NOT NULL,
        actor_attribution TEXT,
        timestamp TEXT NOT NULL,
        outcome TEXT NOT NULL CHECK (outcome IN ('success', 'failure', 'noop')),
        summary TEXT NOT NULL,
        evidence_refs_json TEXT NOT NULL DEFAULT '[]',
        artifact_refs_json TEXT NOT NULL DEFAULT '[]',
        state_versions_json TEXT,
        metadata_json TEXT,
        UNIQUE (id, namespace_id)
      );
      CREATE INDEX IF NOT EXISTS idx_receipts_ns_timestamp ON receipts(namespace_id, timestamp DESC);
      CREATE INDEX IF NOT EXISTS idx_receipts_ns_task ON receipts(namespace_id, task_id, timestamp DESC);
      CREATE INDEX IF NOT EXISTS idx_receipts_ns_project ON receipts(namespace_id, project_id, timestamp DESC);
      CREATE INDEX IF NOT EXISTS idx_receipts_ns_operation ON receipts(namespace_id, operation);

      -- 9. Capability Observations
      CREATE TABLE IF NOT EXISTS capability_observations (
        id TEXT PRIMARY KEY,
        namespace_id TEXT NOT NULL,
        machine_or_runtime_id TEXT NOT NULL,
        kind TEXT NOT NULL CHECK (kind IN (
          'static_capability', 'measured_performance', 'last_known_availability'
        )),
        backend TEXT,
        observations_json TEXT NOT NULL,
        measurement_method TEXT,
        measured_at TEXT NOT NULL,
        valid_until TEXT,
        source_receipt_id TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (source_receipt_id, namespace_id) REFERENCES receipts(id, namespace_id) ON DELETE RESTRICT
      );
      CREATE INDEX IF NOT EXISTS idx_cap_obs_ns_machine_kind ON capability_observations(namespace_id, machine_or_runtime_id, kind, measured_at DESC);

      -- 10. Knowledge Navigation
      CREATE TABLE IF NOT EXISTS knowledge_navigation (
        id TEXT PRIMARY KEY,
        namespace_id TEXT NOT NULL,
        task_id TEXT NOT NULL,
        domain TEXT NOT NULL,
        subject TEXT NOT NULL,
        chapter_or_concept TEXT NOT NULL,
        prerequisite_refs_json TEXT NOT NULL DEFAULT '[]',
        source_refs_json TEXT NOT NULL DEFAULT '[]',
        current_position TEXT NOT NULL,
        unresolved_items_json TEXT NOT NULL DEFAULT '[]',
        version INTEGER NOT NULL DEFAULT 1 CHECK (version >= 1),
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        UNIQUE (namespace_id, task_id),
        FOREIGN KEY (task_id, namespace_id) REFERENCES tasks(id, namespace_id) ON DELETE RESTRICT
      );
      CREATE INDEX IF NOT EXISTS idx_knowledge_nav_ns_task ON knowledge_navigation(namespace_id, task_id);

      -- 11. Idempotency Keys Ledger
      CREATE TABLE IF NOT EXISTS idempotency_keys (
        namespace_id TEXT NOT NULL,
        idempotency_key TEXT NOT NULL,
        operation TEXT NOT NULL,
        payload_hash TEXT NOT NULL,
        receipt_id TEXT NOT NULL,
        response_json TEXT NOT NULL,
        created_at TEXT NOT NULL,
        PRIMARY KEY (namespace_id, idempotency_key)
      );
      CREATE INDEX IF NOT EXISTS idx_idempotency_ns_created ON idempotency_keys(namespace_id, created_at DESC);
    `,
  },
];

export function computeMigrationChecksum(sql: string): string {
  return crypto.createHash('sha256').update(sql.trim(), 'utf8').digest('hex');
}
