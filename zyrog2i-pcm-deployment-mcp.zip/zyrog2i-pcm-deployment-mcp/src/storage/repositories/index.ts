import {
  AcceptanceCriterion,
  ArtifactRecord,
  ArtifactVerificationStatus,
  CapabilityObservationKind,
  CapabilityObservationRecord,
  DecisionOption,
  DecisionRecord,
  KnowledgeNavigationRecord,
  MemoryRecord,
  MemoryScope,
  MemoryStatus,
  MemoryType,
  PrivacyClassification,
  ProjectRecord,
  ProjectStatus,
  ProvenanceInfo,
  ReceiptOutcome,
  ReceiptRecord,
  RuntimeRouteRecord,
  RuntimeRouteStatus,
  TaskAssignment,
  TaskBlocker,
  TaskOpenQuestion,
  TaskPriority,
  TaskRecord,
  TaskStatus,
  TaskVerificationStatus,
  UserProfile,
} from '../../domain/schemas';
import { SqliteDatabase } from '../database';

function safeJsonParse<T>(raw: unknown, fallback: T): T {
  if (typeof raw !== 'string' || raw.trim() === '') {
    return fallback;
  }
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function mapProfileRow(row: Record<string, unknown>): UserProfile {
  return {
    id: String(row.id),
    namespace_id: String(row.namespace_id),
    clarification_strictness: row.clarification_strictness as UserProfile['clarification_strictness'],
    risk_tolerance: row.risk_tolerance as UserProfile['risk_tolerance'],
    tone: row.tone as UserProfile['tone'],
    verbosity: row.verbosity as UserProfile['verbosity'],
    expertise_mode: row.expertise_mode as UserProfile['expertise_mode'],
    assumption_handling: row.assumption_handling as UserProfile['assumption_handling'],
    verification_effort: row.verification_effort as UserProfile['verification_effort'],
    autonomy: row.autonomy as UserProfile['autonomy'],
    version: Number(row.version),
    created_at: String(row.created_at),
    updated_at: String(row.updated_at),
  };
}

export function mapMemoryRow(row: Record<string, unknown>): MemoryRecord {
  return {
    id: String(row.id),
    namespace_id: String(row.namespace_id),
    content: String(row.content),
    type: row.type as MemoryType,
    scope: row.scope as MemoryScope,
    project_id: row.project_id ? String(row.project_id) : null,
    task_id: row.task_id ? String(row.task_id) : null,
    tags: safeJsonParse<string[]>(row.tags_json, []),
    source_type: row.source_type ? String(row.source_type) : null,
    source_ref: row.source_ref ? String(row.source_ref) : null,
    confidence: row.confidence !== null && row.confidence !== undefined ? Number(row.confidence) : null,
    privacy_classification: (row.privacy_classification as PrivacyClassification) ?? 'internal',
    expires_at: row.expires_at ? String(row.expires_at) : null,
    status: row.status as MemoryStatus,
    version: Number(row.version),
    provenance: safeJsonParse<ProvenanceInfo | null>(row.provenance_json, null),
    created_at: String(row.created_at),
    updated_at: String(row.updated_at),
  };
}

export function mapProjectRow(row: Record<string, unknown>): ProjectRecord {
  return {
    id: String(row.id),
    namespace_id: String(row.namespace_id),
    name: String(row.name),
    description: row.description ? String(row.description) : null,
    objectives: safeJsonParse<string[]>(row.objectives_json, []),
    constraints: safeJsonParse<string[]>(row.constraints_json, []),
    status: row.status as ProjectStatus,
    version: Number(row.version),
    provenance: safeJsonParse<ProvenanceInfo | null>(row.provenance_json, null),
    created_at: String(row.created_at),
    updated_at: String(row.updated_at),
  };
}

export function mapTaskRow(row: Record<string, unknown>): TaskRecord {
  return {
    id: String(row.id),
    namespace_id: String(row.namespace_id),
    project_id: row.project_id ? String(row.project_id) : null,
    title: String(row.title),
    initial_request_summary: row.initial_request_summary
      ? String(row.initial_request_summary)
      : null,
    confirmed_specification: safeJsonParse<Record<string, unknown> | string>(
      row.confirmed_specification_json,
      {}
    ),
    constraints: safeJsonParse<string[]>(row.constraints_json, []),
    assumptions: safeJsonParse<string[]>(row.assumptions_json, []),
    acceptance_criteria: safeJsonParse<AcceptanceCriterion[]>(row.acceptance_criteria_json, []),
    status: row.status as TaskStatus,
    priority: (row.priority as TaskPriority) ?? 'medium',
    current_stage: row.current_stage ? String(row.current_stage) : null,
    assignments: safeJsonParse<TaskAssignment[]>(row.assignments_json, []),
    dependency_refs: safeJsonParse<string[]>(row.dependency_refs_json, []),
    open_questions: safeJsonParse<TaskOpenQuestion[]>(row.open_questions_json, []),
    blockers: safeJsonParse<TaskBlocker[]>(row.blockers_json, []),
    verification_status: row.verification_status as TaskVerificationStatus,
    version: Number(row.version),
    provenance: safeJsonParse<ProvenanceInfo | null>(row.provenance_json, null),
    created_at: String(row.created_at),
    updated_at: String(row.updated_at),
  };
}

export function mapDecisionRow(row: Record<string, unknown>): DecisionRecord {
  return {
    id: String(row.id),
    namespace_id: String(row.namespace_id),
    task_id: String(row.task_id),
    state_version_observed: Number(row.state_version_observed),
    objective: String(row.objective),
    options: safeJsonParse<DecisionOption[]>(row.options_json, []),
    chosen_option: String(row.chosen_option),
    selection_basis: row.selection_basis ? String(row.selection_basis) : null,
    assessment_confidence:
      row.assessment_confidence !== null && row.assessment_confidence !== undefined
        ? Number(row.assessment_confidence)
        : null,
    escalation: row.escalation ? String(row.escalation) : null,
    evidence_refs: safeJsonParse<string[]>(row.evidence_refs_json, []),
    provenance: safeJsonParse<ProvenanceInfo | null>(row.provenance_json, null),
    created_at: String(row.created_at),
  };
}

export function mapArtifactRow(row: Record<string, unknown>): ArtifactRecord {
  return {
    id: String(row.id),
    namespace_id: String(row.namespace_id),
    task_id: row.task_id ? String(row.task_id) : null,
    project_id: row.project_id ? String(row.project_id) : null,
    name: String(row.name),
    description: row.description ? String(row.description) : null,
    type: String(row.type),
    relative_path_or_external_reference: String(row.relative_path_or_external_reference),
    mime_type: row.mime_type ? String(row.mime_type) : null,
    size_bytes: row.size_bytes !== null && row.size_bytes !== undefined ? Number(row.size_bytes) : null,
    checksum: row.checksum ? String(row.checksum) : null,
    provenance: safeJsonParse<ProvenanceInfo | null>(row.provenance_json, null),
    verification_status: (row.verification_status as ArtifactVerificationStatus) ?? 'unverified',
    created_at: String(row.created_at),
  };
}

export function mapRuntimeRouteRow(row: Record<string, unknown>): RuntimeRouteRecord {
  return {
    id: String(row.id),
    namespace_id: String(row.namespace_id),
    task_id: String(row.task_id),
    route_summary: String(row.route_summary),
    status: row.status as RuntimeRouteStatus,
    assessment_confidence:
      row.assessment_confidence !== null && row.assessment_confidence !== undefined
        ? Number(row.assessment_confidence)
        : null,
    selection_probability:
      row.selection_probability !== null && row.selection_probability !== undefined
        ? Number(row.selection_probability)
        : null,
    suitability_score:
      row.suitability_score !== null && row.suitability_score !== undefined
        ? Number(row.suitability_score)
        : null,
    observations: safeJsonParse<string[]>(row.observations_json, []),
    evidence_refs: safeJsonParse<string[]>(row.evidence_refs_json, []),
    next_action: row.next_action ? String(row.next_action) : null,
    created_at: String(row.created_at),
  };
}

export function mapCapabilityObservationRow(
  row: Record<string, unknown>
): CapabilityObservationRecord {
  return {
    id: String(row.id),
    namespace_id: String(row.namespace_id),
    machine_or_runtime_id: String(row.machine_or_runtime_id),
    kind: row.kind as CapabilityObservationKind,
    backend: row.backend ? String(row.backend) : null,
    observations: safeJsonParse<Record<string, unknown>>(row.observations_json, {}),
    measurement_method: row.measurement_method ? String(row.measurement_method) : null,
    measured_at: String(row.measured_at),
    valid_until: row.valid_until ? String(row.valid_until) : null,
    source_receipt_id: row.source_receipt_id ? String(row.source_receipt_id) : null,
    created_at: String(row.created_at),
  };
}

export function mapReceiptRow(row: Record<string, unknown>): ReceiptRecord {
  return {
    id: String(row.id),
    namespace_id: String(row.namespace_id),
    task_id: row.task_id ? String(row.task_id) : null,
    project_id: row.project_id ? String(row.project_id) : null,
    correlation_id: row.correlation_id ? String(row.correlation_id) : null,
    idempotency_key: row.idempotency_key ? String(row.idempotency_key) : null,
    event_type: String(row.event_type),
    operation: String(row.operation),
    actor_attribution: row.actor_attribution ? String(row.actor_attribution) : null,
    timestamp: String(row.timestamp),
    outcome: row.outcome as ReceiptOutcome,
    summary: String(row.summary),
    evidence_refs: safeJsonParse<string[]>(row.evidence_refs_json, []),
    artifact_refs: safeJsonParse<string[]>(row.artifact_refs_json, []),
    state_versions: safeJsonParse<Record<string, number> | null>(row.state_versions_json, null),
    metadata: safeJsonParse<Record<string, unknown> | null>(row.metadata_json, null),
  };
}

export function mapKnowledgeNavigationRow(
  row: Record<string, unknown>
): KnowledgeNavigationRecord {
  return {
    id: String(row.id),
    namespace_id: String(row.namespace_id),
    task_id: String(row.task_id),
    domain: String(row.domain),
    subject: String(row.subject),
    chapter_or_concept: String(row.chapter_or_concept),
    prerequisite_refs: safeJsonParse<string[]>(row.prerequisite_refs_json, []),
    source_refs: safeJsonParse<string[]>(row.source_refs_json, []),
    current_position: String(row.current_position),
    unresolved_items: safeJsonParse<string[]>(row.unresolved_items_json, []),
    version: Number(row.version),
    created_at: String(row.created_at),
    updated_at: String(row.updated_at),
  };
}

export class PcmRepositories {
  constructor(
    public readonly db: SqliteDatabase,
    public readonly namespace: string
  ) {}

  public countByNamespace(table: string): number {
    const row = this.db.get<{ cnt: number }>(
      `SELECT COUNT(*) as cnt FROM ${table} WHERE namespace_id = ?`,
      [this.namespace]
    );
    return row ? Number(row.cnt) : 0;
  }
}
